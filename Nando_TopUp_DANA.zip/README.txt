NANDO TOPUP - Website Top Up Game

Cara memakai:
1. Buka index.html di browser.
2. Ganti nomor DANA 08XXXXXXXXXX dengan nomor DANA penerima milikmu.
3. Ganti 628XXXXXXXXXX pada fungsi sendWA() dengan nomor WhatsApp admin.
4. Sesuaikan game, nominal, dan harga di bagian `items`.

Catatan:
Versi ini memakai pembayaran DANA secara MANUAL: pelanggan transfer ke DANA kamu lalu mengirim bukti pembayaran.
Ini belum terhubung ke API DANA/payment gateway atau provider top-up otomatis.
